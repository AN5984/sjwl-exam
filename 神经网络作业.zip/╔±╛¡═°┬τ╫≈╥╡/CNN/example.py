import skimage.io
import numpy
import matplotlib.pyplot as plt
import NumPyCNN as numpycnn
plt.rcParams['font.sans-serif']=['SimHei']
plt.rcParams['axes.unicode_minus'] =False #减号unicode编码



img = skimage.io.imread('图书馆.jpg')


img = skimage.color.rgb2gray(img)


l1_filter = numpy.zeros((2,3,3))
l1_filter[0, :, :] = numpy.array([[[-1, 0, 1],
                                   [-1, 0, 1],
                                   [-1, 0, 1]]])
l1_filter[1, :, :] = numpy.array([[[1,   1,  1],
                                   [0,   0,  0],
                                   [-1, -1, -1]]])


l1_feature_map = numpycnn.conv(img, l1_filter)

l1_feature_map_relu = numpycnn.relu(l1_feature_map)

l1_feature_map_relu_pool = numpycnn.pooling(l1_feature_map_relu, 2, 2)




l2_filter = numpy.random.rand(1, 7, 7, l1_feature_map_relu_pool.shape[-1])

l2_feature_map = numpycnn.conv(l1_feature_map_relu_pool, l2_filter)

l2_feature_map_relu = numpycnn.relu(l2_feature_map)

l2_feature_map_relu_pool = numpycnn.pooling(l2_feature_map_relu, 2, 2)


print("**卷积结束，前往文件夹查看结果**\n")

# 结果
fig0, ax0 = plt.subplots(nrows=1, ncols=1)
ax0.imshow(img).set_cmap("gray")
ax0.set_title("输入图片")
ax0.get_xaxis().set_ticks([])
ax0.get_yaxis().set_ticks([])
plt.savefig("初步处理.png", bbox_inches="tight")
plt.close(fig0)


fig1, ax1 = plt.subplots(nrows=3, ncols=2)
ax1[0, 0].imshow(l1_feature_map[:, :, 0]).set_cmap("gray")
ax1[0, 0].get_xaxis().set_ticks([])
ax1[0, 0].get_yaxis().set_ticks([])
ax1[0, 0].set_title("第一层卷积窗口1")

ax1[0, 1].imshow(l1_feature_map[:, :, 1]).set_cmap("gray")
ax1[0, 1].get_xaxis().set_ticks([])
ax1[0, 1].get_yaxis().set_ticks([])
ax1[0, 1].set_title("第一层卷积窗口2")

ax1[1, 0].imshow(l1_feature_map_relu[:, :, 0]).set_cmap("gray")
ax1[1, 0].get_xaxis().set_ticks([])
ax1[1, 0].get_yaxis().set_ticks([])
ax1[1, 0].set_title("第一层卷积窗口1-ReLU")

ax1[1, 1].imshow(l1_feature_map_relu[:, :, 1]).set_cmap("gray")
ax1[1, 1].get_xaxis().set_ticks([])
ax1[1, 1].get_yaxis().set_ticks([])
ax1[1, 1].set_title("第一层卷积窗口2-ReLU")

ax1[2, 0].imshow(l1_feature_map_relu_pool[:, :, 0]).set_cmap("gray")
ax1[2, 0].get_xaxis().set_ticks([])
ax1[2, 0].get_yaxis().set_ticks([])
ax1[2, 0].set_title("第一层卷积窗口1-ReLU-Pool")

ax1[2, 1].imshow(l1_feature_map_relu_pool[:, :, 1]).set_cmap("gray")
ax1[2, 0].get_xaxis().set_ticks([])
ax1[2, 0].get_yaxis().set_ticks([])
ax1[2, 1].set_title("第一层卷积窗口-2ReLUP-ool")

plt.savefig("第一层结果.png", bbox_inches="tight")
plt.close(fig1)


fig2, ax2 = plt.subplots(nrows=1, ncols=3)

ax2[0].imshow(l2_feature_map[:, :, 0]).set_cmap("gray")
ax2[0].get_xaxis().set_ticks([])
ax2[0].get_yaxis().set_ticks([])
ax2[0].set_title("第二层卷积")

ax2[1].imshow(l2_feature_map_relu[:, :, 0]).set_cmap("gray")
ax2[1].get_xaxis().set_ticks([])
ax2[1].get_yaxis().set_ticks([])
ax2[1].set_title("第二层卷积-ReLU")

ax2[2].imshow(l2_feature_map_relu_pool[:, :, 0]).set_cmap("gray")
ax2[2].get_xaxis().set_ticks([])
ax2[2].get_yaxis().set_ticks([])
ax2[2].set_title("第二层卷积-ReLU-Pool")



plt.savefig("第二层结果.png", bbox_inches="tight")
plt.close(fig2)

