#!/usr/bin/env python
# coding: utf-8

# In[2]:


import tensorflow as tf
import matplotlib.pyplot as plt

from matplotlib import animation, rc
from IPython.display import HTML
import matplotlib.cm as cm
import numpy as np


# In[94]:


#生成数据集
dot_num = 10 
x_p = np.random.normal(2., 1, dot_num) #正态分布，均值2，标准差1，大小为10
y_p = np.random.normal(2., 1, dot_num)#正态分布，均值2，标准差1，大小为10
y1= np.ones(dot_num) #标签设为1
c1 = np.array([x_p, y_p],dtype=np.float32).T #把上面2个数组连接起来成为矩阵，并且转置  这一步是完成联合采样N(2, 2, 1, 1, 0)

x_n = np.random.normal(-2., 1, dot_num)
y_n = np.random.normal(-2., 1, dot_num)
y2= -np.ones(dot_num) #标签设为-1
c2 = np.array([x_n, y_n],dtype=np.float32).T #同上  这一步是完成联合采样N(-2, -2, 1, 1, 0)
ys = np.concatenate((y1, y2), axis=0)

data_set = np.concatenate((c1, c2), axis=0)#连结C1,C2以列连结
np.random.shuffle(data_set)

#上面代码生成以下数据，其中+号代表的是标记1的数据，另一个是标记0的


# In[95]:


# 感知机学习算法的原始形式

# 生成上面的数据做数据集
input=[]
for i in range(10):
    input.append(c1[i])
for i in range(10):
    input.append(c2[i])    

targets=ys
    # 初始化w，b，lr
w = np.zeros(2).reshape(1, 2)
b = 0
lr = 1

while True:
    num_errors = 0
    for i in range(20):
            # 判断是否误分类
        if targets[i] * (np.dot(w, input[i]) + b) <= 0:
                # 更新w，b
            w += lr * targets[i] * input[i].T
            b += lr * targets[i]
                # 误分类个数加1
            num_errors += 1
                
        # M中为空训练结束
    if num_errors == 0:
        print(w, b)
        break
    
    # 画出超平面（二维中即一条直线）
x = (-1+2*np.random.rand(5))*3   #从-3到3随机生成数
y = -(w[0][0] / w[0][1]) * x - b / w[0][1]
plt.plot(x, y, 'g')
# 画出训练集中的点
plt.scatter(c1[:, 0], c1[:, 1], c='b', marker='+')
plt.scatter(c2[:, 0], c2[:, 1], c='g', marker='o')

plt.show()


# In[ ]:





# In[ ]:





# In[ ]:




