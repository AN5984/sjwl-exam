
from __future__ import print_function
from sklearn.metrics import roc_auc_score
from keras.models import Sequential
import numpy as np
from sklearn.metrics import roc_curve, auc
import matplotlib.pyplot as plt
from keras.layers import Dense, Dropout, Activation
from keras.layers.recurrent import SimpleRNN
import pandas as pd
plt.rcParams['font.sans-serif']=['SimHei']
plt.rcParams['axes.unicode_minus'] =False #减号unicode编码
def calculate_performace(test_num, pred_y, labels):
    tp = 0
    fp = 0
    tn = 0
    fn = 0
    for index in range(test_num):
        if labels[index] == 1:
            if labels[index] == pred_y[index]:
                tp = tp + 1
            else:
                fn = fn + 1
        else:
            if labels[index] == pred_y[index]:
                tn = tn + 1
            else:
                fp = fp + 1

    acc = float(tp + tn) / test_num
    precision = float(tp) / (tp + fp)
    sensitivity = float(tp) / (tp + fn)
    specificity = float(tn) / (tn + fp)
    MCC = float(tp * tn - fp * fn) / (np.sqrt((tp + fp) * (tp + fn) * (tn + fp) * (tn + fn)))
    return acc, precision, sensitivity, specificity, MCC
# 训练集标签
def lab_train():
    label = []
    for i in range(500):
        if i < 250:
            label.append(1)
        else:
            label.append(0)
    return label
# 测试集标签
def lab_test():
    label = []
    for i in range(164):
        if i < 82:
            label.append(1)
        else:
            label.append(0)
    return label
def plot_roc_curve(labels, probality, legend_text, auc_tag=True):

    fpr, tpr, thresholds = roc_curve(labels, probality)  
    roc_auc = auc(fpr, tpr)
    if auc_tag:
        rects1 = plt.plot(fpr, tpr, label=legend_text + ' (AUC=%6.3f) ' % roc_auc)
    else:
        rects1 = plt.plot(fpr, tpr, label=legend_text)
def PreRNN():
    nbatch = 16 
    nepochs = 50 
    f_d = 20
    all_prob = {}
    all_prob[0] = []
    y_train = lab_train()
    y_train = np.array(y_train)
    data = pd.read_csv(open(r'RNN数据.tsv'), sep='\t')
    data = data.iloc[:, 1:].reset_index(drop=True)
    data = np.array(data)
    data = np.reshape(data, (len(data), f_d, 1))
    data_test = pd.read_csv(open(r'RNN数据text.tsv'), sep='\t')
    data_test = data_test.iloc[:, 1:].reset_index(drop=True)
    data_test = np.array(data_test)
    data_test = np.reshape(data_test, (len(data_test), f_d, 1))
    train = data
    train_label = lab_train()
    test = data_test
    test_label = lab_test()
    model = Sequential()
    model.add(SimpleRNN(128, return_sequences=False, input_shape=(f_d, 1),
                   ))
    model.add(Dropout(0.25, name='dropout'))
    model.add(Dense(1, name='full_connect'))
    model.add(Activation('sigmoid'))
    model.summary()
    print('运行模型')
    model.compile(loss='binary_crossentropy',  #
                  optimizer='adam',
                  metrics=['accuracy'])
    model.fit(train, np.array(train_label), epochs=nepochs, batch_size=nbatch, verbose=1)
    preds = model.predict(test)
    lstm_class = np.rint(preds)
    all_prob[0] = all_prob[0] + [val for val in preds]
    acc, precision, sensitivity, specificity, MCC = calculate_performace(len(test_label), lstm_class, test_label)
    roc = roc_auc_score(test_label, preds) * 100.0
    print(acc, precision, sensitivity, specificity, MCC, roc)
    print('---' * 50)
    print('平均性能')
    print('---' * 50)
    plot_roc_curve(test_label, preds, 'RNN')
    plt.plot([0, 1], [0, 1], 'k--')
    plt.xlim([-0.05, 1.05])
    plt.ylim([0, 1.05])
    plt.xlabel('正负比率')
    plt.ylabel('真假比率')
    plt.title('ROC')
    plt.legend(loc="lower right")
    plt.show()
PreRNN()


