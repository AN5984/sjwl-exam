import math
import random
import string
import numpy as np

random.seed(0)
# 生成a到b的随机数
def rand(a,b):
    return (b - a) * random.random() + a

# 定义tanh
def tanhforward(X):
    return np.tanh(X)
# 反向传播tanh
def tanhbackward(y):
    return 1.0 - y ** 2
# 生成矩阵
def makeMatrix(r, l, fill=0.0):
    m = []
    for i in range(r):
        m.append([fill]*l)
    return m




class Model():
    def __init__(self, ni, nh, no):
        # 三层的节点数
        self.in_ = ni + 1
        self.hidden = nh
        self.out = no
        self.ai = [1.0] * self.in_
        self.ah = [1.0] * self.hidden
        self.ao = [1.0] * self.out


        # 生成权重矩阵
        # 输入层-->隐藏层
        self.wi = makeMatrix(self.in_, self.hidden)
        for i in range(self.in_):
            for j in range(self.hidden):
                self.wi[i][j] = rand(-0.2, 0.2)
        # 隐藏层-->输出层
        self.wo = makeMatrix(self.hidden, self.out)
        for j in range(self.hidden):
            for k in range(self.out):
                self.wo[j][k] = rand(-2.0, 2.0)

        self.ci = makeMatrix(self.in_, self.hidden)
        self.co = makeMatrix(self.hidden, self.out)
    # 前向传播
    def update(self, inputs):
        # 输入层
        for i in range(self.in_ - 1):
            self.ai[i] = inputs[i]
        # 隐藏层
        for j in range(self.hidden):
            sum = 0.0
            for i in range(self.in_):
                sum = sum + self.ai[i] * self.wi[i][j]
            self.ah[j] = tanhforward(sum)
        #输出层
        for k in range(self.out):
            sum = 0.0
            for j in range(self.hidden):
                sum = sum + self.ah[j] * self.wo[j][k]
            self.ao[k] = tanhforward(sum)
        return self.ao[:]
    # 反向传播
    def backPropagate(self, targets, N, M):
        output_deltas = [0.0] * self.out
        # 计算输出层误差
        for k in range(self.out):
            error = targets[k] - self.ao[k]
            output_deltas[k] = tanhbackward(self.ao[k]) * error
        # 隐藏层误差
        hidden_deltas = [0.0] * self.hidden
        for j in range(self.hidden):
            error = 0.0
            for k in range(self.out):
                error = error + output_deltas[k] * self.wo[j][k]
            hidden_deltas[j] = tanhbackward(self.ah[j]) * error
        # 更新权重
        # 输出层
        for j in range(self.hidden):
            for k in range(self.out):
                change = output_deltas[k] * self.ah[j]
                self.wo[j][k] = self.wo[j][k] + N * change + M * self.co[j][k]
                self.co[j][k] = change
        # 输入层
        for i in range(self.in_):
            for j in range(self.hidden):
                change = hidden_deltas[j] * self.ai[i]
                self.wi[i][j] = self.wi[i][j] + N * change + M * self.ci[i][j]
                self.ci[i][j] = change
        error = 0.0
        for k in range(len(targets)):
            error = error + 0.5*(targets[k]-self.ao[k])**2
        return error
    def test(self, patterns):
        for p in patterns:
            print(p[0], '->', self.update(p[0]))

    def weights(self):
        print("输入层权重")
        for i in range(self.in_):
            print(self.wi[i])
        print()
        print("输出层权重")
        for j in range(self.hidden):
            print(self.wo[i])

    def train(self, patterns, iterations=1000, N=0.5, M=0.1):
        for i in range(iterations):
            error = 0.0
            for p in patterns:
                inputs = p[0]
                targets = p[1]
                self.update(inputs)
                error = error + self.backPropagate(targets, N, M)
            if i % 100 == 0:
                print('误差 %-.6f' % error)

def main():
    pat = [
        [[0,0],[1]],
        [[0,1],[0]],
        [[1,0],[0]],
        [[1,1],[1]]
    ]
    n = Model(2,2,1)
    n.train(pat)
    n.test(pat)

main()

